# Security Policy

## Supported Versions

| Version      | Supported          |
| ------------ | ------------------ |
| 2021-06-23   | :white_check_mark: |
| 2021-05-05   | :white_check_mark: |
| < 2021-04-20 | :x:                |

## Reporting a Vulnerability

Report a security vulnerability to https://github.com/vinceliuice/WhiteSur-gtk-theme/issues
with a blank template or contact one of the authors.
